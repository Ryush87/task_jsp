package myspring.di.annot.javaconfig;

public interface Printer {
	public void print(String message);
}
