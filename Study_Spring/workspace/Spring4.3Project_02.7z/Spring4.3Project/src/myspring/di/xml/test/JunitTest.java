package myspring.di.xml.test;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import myspring.di.xml.Hello;
import myspring.di.xml.Printer;

public class JunitTest {
	
	ApplicationContext context;
	
	@Before
	public void setup() {
		//1. Bean Container ��ü����
		context = new GenericXmlApplicationContext("config/app_context.xml");
	}
	
	@Test
	public void bean() {
		//1. Bean Container���� bean �� ��û
		Hello hello1 = (Hello)context.getBean("hello");
		Hello hello2 = context.getBean("hello", Hello.class);
		System.out.println(hello1 == hello2);
		
		//reference �� �ϴ� �޼ҵ�
		Assert.assertSame(hello1,  hello2);
		
		//value ���ϴ� �޼���
		Assert.assertEquals("Hello �����������̼�", hello1.sayHello());
		
		hello1.print();
		Printer printer = context.getBean("sPrinter", Printer.class);		
		Assert.assertEquals("Hello �����������̼�", printer.toString());
	}
	
}
