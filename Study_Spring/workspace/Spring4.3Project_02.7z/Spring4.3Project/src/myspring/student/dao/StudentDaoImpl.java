package myspring.student.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import myspring.user.dao.mapper.StudentMapper;
import myspring.user.vo.StudentVO;

@Repository("studentDao")
public class StudentDaoImpl implements studentDao {
	
	@Autowired
	private StudentMapper studentMapper;
	
	@Override
	public StudentVO getStudentById(int id) {
		return studentMapper.selectStudentById(id);
	}
	
	@Override
	public List<StudentVO> getStudentDeptById(){
		return studentMapper.selectStudentDeptById();
	}
	
	@Override
	public List<StudentVO> getStudentCourseStatusById(){
		return studentMapper.selectStudentCourseStatusById();
	}
}
