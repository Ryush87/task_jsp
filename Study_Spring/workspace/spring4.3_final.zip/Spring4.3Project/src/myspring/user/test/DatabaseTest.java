package myspring.user.test;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import myspring.student.dao.StudentDao;
import myspring.user.service.UserService;
import myspring.user.vo.StudentVO;
import myspring.user.vo.UserVO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:/config/application_context.xml")
public class DatabaseTest {
	@Autowired
	SqlSession sqlSession;
	
	@Autowired
	UserService userService;
	
	@Autowired
	StudentDao studentDao;
	
	@Test @Ignore
	public void student() {
		StudentVO stu = studentDao.getStudentById(1002);
		System.out.println(stu);
		
		List<StudentVO> stuList = studentDao.getStudentDeptById();
		for (StudentVO studentVO : stuList) {
			System.out.println(studentVO);
		}
		
		List<StudentVO> stuList2 = studentDao.getStudentCourseStatusById();
		for (StudentVO studentVO : stuList2) {
			System.out.println(studentVO);
		}
	}
	
	@Test //@Ignore
	public void service() {
		UserVO user = new UserVO("vega2k", "�׽�Ʈ2", "��2","����2");
		userService.updateUser(user);			
		
		List<UserVO> userList = userService.getUserList();
		for (UserVO userVO : userList) {
			System.out.println(userVO);
		}
	}
	
	@Test @Ignore
	public void user() {
		UserVO user = sqlSession.selectOne("userNS.selectUserById", "gildong");
		System.out.println(user);
	}
}
