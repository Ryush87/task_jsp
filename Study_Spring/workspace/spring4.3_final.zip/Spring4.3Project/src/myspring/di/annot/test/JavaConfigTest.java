package myspring.di.annot.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import myspring.di.annot.Hello;
import myspring.di.annot.Printer;
import myspring.di.annot.config.HelloBeanConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=HelloBeanConfig.class,
loader=AnnotationConfigContextLoader.class)
public class JavaConfigTest {
	@Autowired
	ApplicationContext context;
	
	@Autowired
	Hello hello;
	
	@Autowired
	@Qualifier("stringPrinter")
	Printer printer;
	
	@Test
	public void bean() {
		System.out.println(context.getClass().getName());
		assertEquals("Hello ������̼�", hello.sayHello());
		hello.print();
		assertEquals("Hello ������̼�", printer.toString());
	}
}
