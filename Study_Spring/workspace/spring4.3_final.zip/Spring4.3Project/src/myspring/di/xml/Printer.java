package myspring.di.xml;

public interface Printer {
	public void print(String message);
}
