package myspring.di.xml.test;

import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import myspring.di.xml.Hello;
import myspring.di.xml.Printer;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:/config/application_context.xml")
public class SpringTest {
	@Autowired
	ApplicationContext context;
	
	@Autowired
	Hello hello;
	
	@Autowired
	@Qualifier("sPrinter")
//	@Resource(name="sPrinter")
	Printer printer;
	
	@Autowired
	DataSource dataSource;
	
	@Test
	public void db() {
		try {
			System.out.println(dataSource.getConnection());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test @Ignore
	public void bean() {
		System.out.println(context.getClass().getName());
		
		Assert.assertEquals("Hello ������", 
				hello.sayHello());
		hello.print();
		Assert.assertEquals("Hello ������", printer.toString());
	}
}
