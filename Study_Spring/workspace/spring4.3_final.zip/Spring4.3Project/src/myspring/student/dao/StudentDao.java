package myspring.student.dao;

import java.util.List;

import myspring.user.vo.StudentVO;

public interface StudentDao {

	StudentVO getStudentById(int id);

	List<StudentVO> getStudentDeptById();

	List<StudentVO> getStudentCourseStatusById();

}